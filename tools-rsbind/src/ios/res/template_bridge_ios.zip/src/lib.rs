#![allow(warnings)]

extern crate $(*521%-host_crate_underscore);
#[macro_use]
extern crate serde_derive;
extern crate serde;

use $(*521%-host_crate_underscore)::contract;
use $(*521%-host_crate_underscore)::imp;

pub mod c;
