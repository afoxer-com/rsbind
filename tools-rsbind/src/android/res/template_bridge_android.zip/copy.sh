#!/usr/bin/env bash

zip -q -r template_bridge_android.zip ./
mv template_bridge_android.zip ../../tools-rsbind/src/android/res/