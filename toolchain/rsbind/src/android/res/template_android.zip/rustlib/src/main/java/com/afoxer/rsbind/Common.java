package com.afoxer.rsbind;

public class Common {
    public static void loadLibrary(String libName) {
        System.loadLibrary(libName);
    }
}