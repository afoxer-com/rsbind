//
//  ffi.swift
//  rustlib
//
//  Created by sidney.wang on 2018/7/2.
//  Copyright © 2018年 sidney.wang. All rights reserved.
//
import rustlib.ffi
import Foundation
