#!/usr/bin/env bash

zip -q -r template_android.zip ./
mv template_android.zip ../../tools-rsbind/src/android/res/