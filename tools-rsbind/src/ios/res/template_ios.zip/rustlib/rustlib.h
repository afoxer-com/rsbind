//
//  rustlib.h
//  rustlib
//
//  Created by sidney.wang on 2018/6/29.
//  Copyright © 2018年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ffi.h"

//! Project version number for rustlib.
FOUNDATION_EXPORT double rustlibVersionNumber;

//! Project version string for rustlib.
FOUNDATION_EXPORT const unsigned char rustlibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <rustlib/PublicHeader.h>


